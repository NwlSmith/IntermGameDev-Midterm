# I N K

By Nate Smith http://nwlsmith.com

### PC BUILD 1.1

2/20/2020-3/23/2020

Intermediate Game Development Midterm


Github repository: https://github.com/NwlSmith/IntermGameDev-Midterm

itch.io page: https://nwlsmith.itch.io/ink


Mouse to move the machine

Click to start tattooing.

Screenshots located in /INK_Data/screenshots